// RGG2_GUI.cpp
// SDL2 + Dear ImGui GUI wrapper around an ASCII room-graph generator.
// Fixes included:
//  - ImGui::SliderFloat requires float* (we use temp floats, keep Params as double)
//  - ImGui_ImplSDLRenderer2_RenderDrawData needs (draw_data, renderer)

#define SDL_MAIN_HANDLED

#include <SDL.h>
#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <chrono>

#include "imgui.h"
#include "backends/imgui_impl_sdl2.h"
#include "backends/imgui_impl_sdlrenderer2.h"

using namespace std;

/* ==============================
   PARAMS ("KNOBS") HERE
   ============================== */

struct Params {
    int rooms = 64;              // total rooms including start+goal
    int mainLen = 32;            // rooms on the main path (>=2)
    double branchChance = 0.95;  // chance to spawn a branch from each base node
    int maxBranchLen = 16;       // max rooms in a branch chain
    double loopChance = 0.0;     // chance to add a loop/shortcut edge

    // Multi-room controls (block rooms only)
    double multiRoomChance = 0.35; // chance to try multi-room footprint
    int minRoomW = 1;             // min room width in room-cells
    int maxRoomW = 3;             // max room width in room-cells
    int minRoomH = 1;             // min room height in room-cells
    int maxRoomH = 3;             // max room height in room-cells

    // Room-type weights 
    int wHealth = 12; // H
    int wMonster = 28; // M
    int wTreasure = 14; // T
    int wKey = 8;  // K
    int wBoss = 3;  // B
    int wPuzzle = 10; // P
    int wRest = 8;  // R

    int W = 69, H = 39;           // render canvas size
    unsigned seed = 53;
};

static Params DefaultParams() { return Params{}; }

static bool inBounds(int x, int y, int W, int H) {
    return x >= 0 && y >= 0 && x < W && y < H;
}

/* ==============================
   ROOM TYPES (meaning tags)
   ============================== */

struct RoomType {
    char glyph;
    const char* name;
    const char* var;
    int weight;
};

static vector<RoomType> makeRoomTypes(const Params& p) {
    return {
        {'H', "Health Room",   "HEALTH",   p.wHealth},
        {'M', "Monster Room",  "MONSTER",  p.wMonster},
        {'T', "Treasure Room", "TREASURE", p.wTreasure},
        {'K', "Key Room",      "KEY",      p.wKey},
        {'B', "Boss Room",     "BOSS",     p.wBoss},
        {'P', "Puzzle Room",   "PUZZLE",   p.wPuzzle},
        {'R', "Rest Room",     "REST",     p.wRest}
    };
}

/* ==============================
   GENERATOR STRUCTS
   ============================== */

struct Node {
    int id;
    int x, y;      // center room cell in canvas coords (odd,odd)
    int rw, rh;    // footprint size in room-cells
    char glyph;    // ASCII display
    string tag;    // "Monster Room"
    string varTag; // "MONSTER"
};

struct Edge { int a, b; };

/* ==============================
   GENERATOR
   ============================== */

struct Generator {
    Params p;
    mt19937 rng;

    vector<Node> nodes;
    vector<Edge> edges;
    vector<vector<int>> adj;
    vector<vector<bool>> used; // occupancy of room positions (odd,odd)
    vector<RoomType> roomTypes;

    Generator(const Params& params) : p(params), rng(params.seed) {
        used.assign(p.H, vector<bool>(p.W, false));
        roomTypes = makeRoomTypes(p);
    }

    int randi(int lo, int hi) {
        uniform_int_distribution<int> dist(lo, hi);
        return dist(rng);
    }

    double rand01() {
        uniform_real_distribution<double> dist(0.0, 1.0);
        return dist(rng);
    }

    bool occupied(int x, int y) const {
        if (!inBounds(x, y, p.W, p.H)) return true;
        return used[y][x];
    }

    RoomType pickRoomType() {
        int totalW = 0;
        for (auto& t : roomTypes) totalW += max(0, t.weight);
        if (totalW <= 0) return { 'M', "Monster Room", "MONSTER", 1 };

        int roll = randi(1, totalW);
        int running = 0;
        for (auto& t : roomTypes) {
            running += max(0, t.weight);
            if (roll <= running) return t;
        }
        return roomTypes.back();
    }

    // check if a room footprint fits (rooms occupy odd coords spaced by 2)
    bool canPlaceFootprint(int cx, int cy, int rw, int rh) const {
        if (!inBounds(cx, cy, p.W, p.H)) return false;
        if (cx % 2 == 0 || cy % 2 == 0) return false;

        int ox = rw / 2;
        int oy = rh / 2;

        for (int dy = -oy; dy <= oy; ++dy) {
            for (int dx = -ox; dx <= ox; ++dx) {
                int x = cx + 2 * dx;
                int y = cy + 2 * dy;

                if (!inBounds(x, y, p.W, p.H)) return false;
                if (x % 2 == 0 || y % 2 == 0) return false;
                if (occupied(x, y)) return false;
            }
        }
        return true;
    }

    void markFootprintUsed(int cx, int cy, int rw, int rh, bool value) {
        int ox = rw / 2;
        int oy = rh / 2;

        for (int dy = -oy; dy <= oy; ++dy) {
            for (int dx = -ox; dx <= ox; ++dx) {
                int x = cx + 2 * dx;
                int y = cy + 2 * dy;
                if (inBounds(x, y, p.W, p.H)) used[y][x] = value;
            }
        }
    }

    pair<int, int> pickRoomSize() {
        int rw = 1, rh = 1;

        if (rand01() < p.multiRoomChance) {
            int wMin = max(1, p.minRoomW);
            int hMin = max(1, p.minRoomH);
            int wMax = max(wMin, p.maxRoomW);
            int hMax = max(hMin, p.maxRoomH);

            rw = randi(wMin, wMax);
            rh = randi(hMin, hMax);

            if (rw == 1 && rh == 1) {
                if (wMax >= 2) rw = 2;
                else if (hMax >= 2) rh = 2;
            }
        }

        // prefer odd so blocks are symmetric around center
        auto makeOdd = [&](int& v, int maxv) {
            if (v % 2 == 0) {
                if (v + 1 <= maxv) v += 1;
                else v = max(1, v - 1);
            }
            };

        makeOdd(rw, max(1, p.maxRoomW));
        makeOdd(rh, max(1, p.maxRoomH));

        rw = max(1, min(rw, max(1, p.maxRoomW)));
        rh = max(1, min(rh, max(1, p.maxRoomH)));
        return { rw, rh };
    }

    bool placeRoom(int id, int x, int y, char g) {
        if (!inBounds(x, y, p.W, p.H)) return false;
        if (x % 2 == 0 || y % 2 == 0) return false;

        string tag, varTag;
        char glyph = g;

        if (g == 'S') { tag = "Start"; varTag = "START"; }
        else if (g == 'G') { tag = "Goal"; varTag = "GOAL"; }
        else {
            RoomType rt = pickRoomType();
            glyph = rt.glyph;
            tag = rt.name;
            varTag = rt.var;
        }

        for (int tries = 0; tries < 12; ++tries) {
            auto sz = pickRoomSize();
            int rw = sz.first, rh = sz.second;
            if (canPlaceFootprint(x, y, rw, rh)) {
                markFootprintUsed(x, y, rw, rh, true);
                nodes.push_back({ id, x, y, rw, rh, glyph, tag, varTag });
                if ((int)adj.size() <= id) adj.resize(id + 1);
                return true;
            }
        }

        if (canPlaceFootprint(x, y, 1, 1)) {
            markFootprintUsed(x, y, 1, 1, true);
            nodes.push_back({ id, x, y, 1, 1, glyph, tag, varTag });
            if ((int)adj.size() <= id) adj.resize(id + 1);
            return true;
        }

        return false;
    }

    bool hasEdge(int a, int b) const {
        if (a < 0 || b < 0) return false;
        if (a >= (int)adj.size() || b >= (int)adj.size()) return false;
        for (int v : adj[a]) if (v == b) return true;
        return false;
    }

    void addEdge(int a, int b) {
        if (a == b) return;
        if (a < 0 || b < 0) return;
        if (a >= (int)adj.size() || b >= (int)adj.size()) return;
        if (hasEdge(a, b)) return;

        edges.push_back({ a, b });
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    pair<int, int> randomFreeNeighbor(int x, int y) {
        vector<pair<int, int>> opts = { {x + 2,y},{x - 2,y},{x,y + 2},{x,y - 2} };
        shuffle(opts.begin(), opts.end(), rng);

        for (auto pos : opts) {
            int nx = pos.first, ny = pos.second;
            if (inBounds(nx, ny, p.W, p.H) && nx % 2 == 1 && ny % 2 == 1 && !occupied(nx, ny)) {
                return { nx, ny };
            }
        }
        return { -1, -1 };
    }

    int randomOccupiedNeighborRoomId(int x, int y) {
        vector<pair<int, int>> opts = { {x + 2,y},{x - 2,y},{x,y + 2},{x,y - 2} };
        shuffle(opts.begin(), opts.end(), rng);

        for (auto pos : opts) {
            int nx = pos.first, ny = pos.second;
            for (auto& n : nodes) {
                if (n.x == nx && n.y == ny) return n.id;
            }
        }
        return -1;
    }

    void generate() {
        nodes.clear();
        edges.clear();
        adj.clear();
        used.assign(p.H, vector<bool>(p.W, false));
        roomTypes = makeRoomTypes(p);

        int total = max(2, p.rooms);
        int mainLen = min(max(2, p.mainLen), total);

        // Place start near left/center
        int sx = p.W / 4;
        if (sx % 2 == 0) sx++;
        int sy = p.H / 2;
        if (sy % 2 == 0) sy++;

        if (!placeRoom(0, sx, sy, 'S')) {
            // fallback: first free odd cell
            for (int y = 1; y < p.H; y += 2) {
                for (int x = 1; x < p.W; x += 2) {
                    if (!occupied(x, y)) { placeRoom(0, x, y, 'S'); goto placed; }
                }
            }
        }
    placed:;

        int nextId = 1;
        int prevId = 0;

        // build a main path
        for (int i = 1; i < mainLen; i++) {
            Node& prev = nodes[prevId];

            auto pos = randomFreeNeighbor(prev.x, prev.y);
            int nx = pos.first;
            int ny = pos.second;

            if (nx == -1) {
                bool grown = false;
                for (int tries = 0; tries < 200 && !grown; ++tries) {
                    int pick = randi(0, (int)nodes.size() - 1);
                    auto tpos = randomFreeNeighbor(nodes[pick].x, nodes[pick].y);
                    int tx = tpos.first;
                    int ty = tpos.second;

                    if (tx != -1) {
                        nx = tx; ny = ty;
                        prevId = pick;
                        grown = true;
                    }
                }
                if (nx == -1) break;
            }

            char g = (i == mainLen - 1) ? 'G' : 'X';
            if (!placeRoom(nextId, nx, ny, g)) break;
            addEdge(prevId, nextId);

            prevId = nextId;
            nextId++;
        }

        // Ensure there is a goal
        int goalId = -1;
        for (auto& n : nodes) if (n.varTag == "GOAL") goalId = n.id;
        if (goalId == -1 && !nodes.empty()) {
            goalId = nodes.back().id;
            for (auto& n : nodes) if (n.id == goalId) {
                n.glyph = 'G';
                n.tag = "Goal";
                n.varTag = "GOAL";
            }
        }

        vector<int> baseIds;
        baseIds.reserve(nodes.size());
        for (auto& n : nodes) baseIds.push_back(n.id);

        // grow side chains off base nodes
        for (int bid : baseIds) {
            if (bid == goalId) continue;
            if ((int)nodes.size() >= total) break;
            if (rand01() > p.branchChance) continue;

            int cur = bid;
            int blen = randi(1, p.maxBranchLen);

            for (int step = 0; step < blen && (int)nodes.size() < total; ++step) {
                Node& cn = nodes[cur];

                auto pos = randomFreeNeighbor(cn.x, cn.y);
                int nx = pos.first;
                int ny = pos.second;
                if (nx == -1) break;

                if (!placeRoom(nextId, nx, ny, 'X')) break;
                addEdge(cur, nextId);

                cur = nextId;
                nextId++;

                // small chance to fork off the branch
                if ((int)nodes.size() < total && rand01() < (p.branchChance * 0.35)) {
                    auto fpos = randomFreeNeighbor(nodes[cur].x, nodes[cur].y);
                    int fx = fpos.first;
                    int fy = fpos.second;
                    if (fx != -1 && (int)nodes.size() < total) {
                        if (placeRoom(nextId, fx, fy, 'X')) {
                            addEdge(cur, nextId);
                            nextId++;
                        }
                    }
                }
            }
        }

        // fill leftover space
        int safety = 0;
        while ((int)nodes.size() < total && safety++ < 5000) {
            int pick = randi(0, (int)nodes.size() - 1);

            auto pos = randomFreeNeighbor(nodes[pick].x, nodes[pick].y);
            int nx = pos.first;
            int ny = pos.second;
            if (nx == -1) continue;

            if (!placeRoom(nextId, nx, ny, 'X')) continue;
            addEdge(nodes[pick].id, nextId);
            nextId++;
        }

        // loops/shortcuts
        for (int tries = 0; tries < (int)nodes.size() * 4; ++tries) {
            if (rand01() > p.loopChance) continue;
            int aIndex = randi(0, (int)nodes.size() - 1);
            int bId = randomOccupiedNeighborRoomId(nodes[aIndex].x, nodes[aIndex].y);
            if (bId == -1) continue;
            addEdge(nodes[aIndex].id, bId);
        }
    }

    vector<string> render() {
        vector<string> canvas(p.H, string(p.W, ' '));

        auto put = [&](int x, int y, char c) {
            if (inBounds(x, y, p.W, p.H)) canvas[y][x] = c;
            };

        auto nodeById = [&](int id) -> Node* {
            for (auto& n : nodes) if (n.id == id) return &n;
            return nullptr;
            };

        // corridors
        for (auto& e : edges) {
            Node* A = nodeById(e.a);
            Node* B = nodeById(e.b);
            if (!A || !B) continue;

            int x1 = A->x, y1 = A->y, x2 = B->x, y2 = B->y;

            if (x1 == x2) {
                int sy = min(y1, y2), ey = max(y1, y2);
                for (int y = sy + 1; y < ey; ++y) put(x1, y, '|');
            }
            else if (y1 == y2) {
                int sx = min(x1, x2), ex = max(x1, x2);
                for (int x = sx + 1; x < ex; ++x) put(x, y1, '-');
            }
            else {
                int mx = x2, my = y1;
                int sx = min(x1, mx), ex = max(x1, mx);
                for (int x = sx + 1; x < ex; ++x) put(x, y1, '-');
                int sy = min(y1, y2), ey = max(y1, y2);
                for (int y = sy + 1; y < ey; ++y) put(mx, y, '|');
                put(mx, my, '+');
            }
        }

        // intersections
        for (int y = 0; y < p.H; y++) {
            for (int x = 0; x < p.W; x++) {
                if (canvas[y][x] == '-' || canvas[y][x] == '|') {
                    bool hor = (x > 0 && canvas[y][x - 1] == '-') || (x + 1 < p.W && canvas[y][x + 1] == '-');
                    bool ver = (y > 0 && canvas[y - 1][x] == '|') || (y + 1 < p.H && canvas[y + 1][x] == '|');
                    if (hor && ver) canvas[y][x] = '+';
                }
            }
        }

        // rooms on top (draw footprints)
        for (auto& n : nodes) {
            int ox = n.rw / 2;
            int oy = n.rh / 2;
            for (int dy = -oy; dy <= oy; ++dy) {
                for (int dx = -ox; dx <= ox; ++dx) {
                    int rx = n.x + 2 * dx;
                    int ry = n.y + 2 * dy;
                    put(rx, ry, n.glyph);
                }
            }
        }

        vector<string> out;
        out.push_back("+" + string(p.W, '-') + "+");
        for (int y = 0; y < p.H; y++) out.push_back("|" + canvas[y] + "|");
        out.push_back("+" + string(p.W, '-') + "+");
        return out;
    }

    void writeLegend(ostream& os) {
        os << "Legend:\n";
        os << "  S = Start (START)\n";
        os << "  G = Goal  (GOAL)\n";
        for (auto& t : roomTypes) {
            os << "  " << t.glyph << " = " << t.name << " (" << t.var << "), weight=" << t.weight << "\n";
        }
    }

    void writeCounts(ostream& os) {
        auto countByVar = [&](const string& v) {
            int c = 0;
            for (auto& n : nodes) if (n.varTag == v) c++;
            return c;
            };

        os << "Counts:\n";
        os << "  START: " << countByVar("START") << "\n";
        os << "  GOAL : " << countByVar("GOAL") << "\n";
        for (auto& t : roomTypes) {
            os << "  " << t.var << ": " << countByVar(t.var) << "\n";
        }
    }
};

/* ==============================
   SANITIZE PARAMS
   ============================== */

static void sanitizeParams(Params& p) {
    p.rooms = max(2, p.rooms);
    p.mainLen = max(2, p.mainLen);
    p.mainLen = min(p.mainLen, p.rooms);

    p.branchChance = min(1.0, max(0.0, p.branchChance));
    p.loopChance = min(1.0, max(0.0, p.loopChance));
    p.maxBranchLen = max(1, p.maxBranchLen);

    // don't allow 0x0, etc.
    p.W = max(15, p.W);
    p.H = max(9, p.H);

    p.multiRoomChance = min(1.0, max(0.0, p.multiRoomChance));
    p.minRoomW = max(1, p.minRoomW);
    p.minRoomH = max(1, p.minRoomH);
    p.maxRoomW = max(p.minRoomW, p.maxRoomW);
    p.maxRoomH = max(p.minRoomH, p.maxRoomH);

    p.wHealth = max(0, p.wHealth);
    p.wMonster = max(0, p.wMonster);
    p.wTreasure = max(0, p.wTreasure);
    p.wKey = max(0, p.wKey);
    p.wBoss = max(0, p.wBoss);
    p.wPuzzle = max(0, p.wPuzzle);
    p.wRest = max(0, p.wRest);
}

static string joinLines(const vector<string>& lines) {
    string out;
    out.reserve(lines.size() * 80);
    for (auto& s : lines) { out += s; out += '\n'; }
    return out;
}

static unsigned makeRandomSeed() {
    auto now = chrono::high_resolution_clock::now().time_since_epoch().count();
    return (unsigned)(now ^ (now >> 32));
}

/* ==============================
   BATCH EXPORT
   ============================== */

static bool exportBatchTxt(const Params& base, int samples, const string& filename, string& err) {
    ofstream out(filename);
    if (!out.is_open()) {
        err = "Could not open file for writing: " + filename;
        return false;
    }

    Params p = base;
    sanitizeParams(p);

    for (int s = 0; s < samples; ++s) {
        Params cur = p;
        cur.seed = p.seed + (unsigned)s;

        Generator g(cur);
        g.generate();
        auto img = g.render();

        out << "Graph " << (s + 1) << "  (seed=" << cur.seed << ")\n";
        out << "Params: rooms=" << cur.rooms
            << ", main=" << cur.mainLen
            << ", branch=" << cur.branchChance
            << ", branchlen=" << cur.maxBranchLen
            << ", loops=" << cur.loopChance << "\n";
        out << "RoomSize: multi=" << cur.multiRoomChance
            << ", minrw=" << cur.minRoomW << ", maxrw=" << cur.maxRoomW
            << ", minrh=" << cur.minRoomH << ", maxrh=" << cur.maxRoomH << "\n\n";

        g.writeLegend(out);
        out << "\n";
        g.writeCounts(out);
        out << "\n";

        for (auto& line : img) out << line << "\n";
        if (s != samples - 1) out << "\n";
    }

    return true;
}

/* ==============================
   GUI HELP MARKER
   ============================== */

static void HelpMarker(const char* desc) {
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayShort)) {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
        ImGui::TextUnformatted(desc);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

/* ==============================
   MAIN GUI APP
   ============================== */

int main(int, char**) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) {
        cerr << "SDL_Init failed: " << SDL_GetError() << "\n";
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow(
        "RGG2 - Room Graph Generator (GUI)",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        1200, 800,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );
    if (!window) {
        cerr << "SDL_CreateWindow failed: " << SDL_GetError() << "\n";
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        cerr << "SDL_CreateRenderer failed: " << SDL_GetError() << "\n";
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();

    ImGui_ImplSDL2_InitForSDLRenderer(window, renderer);
    ImGui_ImplSDLRenderer2_Init(renderer);

    Params p = DefaultParams();
    sanitizeParams(p);

    string previewText;
    string statusText = "Ready.";
    int batchSamples = 5;
    char outPath[512] = "batch_output.txt";

    auto regeneratePreview = [&]() {
        sanitizeParams(p);
        Generator g(p);
        g.generate();
        auto img = g.render();

        ostringstream oss;
        oss << "Graph Preview (seed=" << p.seed << ")\n";
        oss << "Params: rooms=" << p.rooms
            << ", main=" << p.mainLen
            << ", branch=" << p.branchChance
            << ", branchlen=" << p.maxBranchLen
            << ", loops=" << p.loopChance << "\n";
        oss << "RoomSize: multi=" << p.multiRoomChance
            << ", minrw=" << p.minRoomW << ", maxrw=" << p.maxRoomW
            << ", minrh=" << p.minRoomH << ", maxrh=" << p.maxRoomH << "\n\n";
        g.writeLegend(oss);
        oss << "\n";
        g.writeCounts(oss);
        oss << "\n";
        oss << joinLines(img);

        previewText = oss.str();
        };

    regeneratePreview();

    bool done = false;
    while (!done) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT) done = true;
            if (event.type == SDL_WINDOWEVENT && event.window.event == SDL_WINDOWEVENT_CLOSE
                && event.window.windowID == SDL_GetWindowID(window)) done = true;
        }

        ImGui_ImplSDLRenderer2_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        // Controls panel
        ImGui::Begin("Controls");

        bool changed = false;

        ImGui::Text("Core Graph Parameters");
        ImGui::Separator();

        changed |= ImGui::SliderInt("rooms", &p.rooms, 2, 300);
        changed |= ImGui::SliderInt("mainLen", &p.mainLen, 2, 300);

        // FIX: SliderFloat wants float*, so use temp float and write back
        float bc = (float)p.branchChance;
        if (ImGui::SliderFloat("branchChance", &bc, 0.0f, 1.0f)) {
            p.branchChance = (double)bc;
            changed = true;
        }

        changed |= ImGui::SliderInt("maxBranchLen", &p.maxBranchLen, 1, 80);

        float lc = (float)p.loopChance;
        if (ImGui::SliderFloat("loopChance", &lc, 0.0f, 1.0f)) {
            p.loopChance = (double)lc;
            changed = true;
        }

        ImGui::Spacing();
        ImGui::Text("Canvas");
        ImGui::Separator();
        changed |= ImGui::SliderInt("W", &p.W, 15, 201);
        changed |= ImGui::SliderInt("H", &p.H, 9, 151);

        ImGui::Spacing();
        ImGui::Text("Room Footprints (Block Rooms)");
        ImGui::Separator();

        float mc = (float)p.multiRoomChance;
        if (ImGui::SliderFloat("multiRoomChance", &mc, 0.0f, 1.0f)) {
            p.multiRoomChance = (double)mc;
            changed = true;
        }

        changed |= ImGui::SliderInt("minRoomW", &p.minRoomW, 1, 25);
        changed |= ImGui::SliderInt("maxRoomW", &p.maxRoomW, 1, 25);
        changed |= ImGui::SliderInt("minRoomH", &p.minRoomH, 1, 25);
        changed |= ImGui::SliderInt("maxRoomH", &p.maxRoomH, 1, 25);
        ImGui::SameLine(); HelpMarker("Room sizes are measured in room-cells (odd coords). 3x3 creates a 3x3 block of glyphs.");

        ImGui::Spacing();
        ImGui::Text("Room Type Weights (Meaningful Glyphs)");
        ImGui::Separator();
        changed |= ImGui::SliderInt("H weight (Health)", &p.wHealth, 0, 60);
        changed |= ImGui::SliderInt("M weight (Monster)", &p.wMonster, 0, 60);
        changed |= ImGui::SliderInt("T weight (Treasure)", &p.wTreasure, 0, 60);
        changed |= ImGui::SliderInt("K weight (Key)", &p.wKey, 0, 60);
        changed |= ImGui::SliderInt("B weight (Boss)", &p.wBoss, 0, 60);
        changed |= ImGui::SliderInt("P weight (Puzzle)", &p.wPuzzle, 0, 60);
        changed |= ImGui::SliderInt("R weight (Rest)", &p.wRest, 0, 60);

        ImGui::Spacing();
        ImGui::Text("Seed");
        ImGui::Separator();

        long long seedTmp = (long long)p.seed;
        if (ImGui::InputScalar("seed", ImGuiDataType_S64, &seedTmp)) {
            if (seedTmp < 0) seedTmp = 0;
            p.seed = (unsigned long long)seedTmp;
            changed = true;
        }
        if (ImGui::Button("Randomize Seed")) {
            p.seed = makeRandomSeed();
            changed = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("Reset Defaults")) {
            p = DefaultParams();
            sanitizeParams(p);
            changed = true;
            statusText = "Reset to defaults.";
        }

        ImGui::Spacing();
        ImGui::Separator();

        if (ImGui::Button("Generate")) {
            regeneratePreview();
            statusText = "Generated preview.";
        }

        // Live preview on change
        if (changed) {
            regeneratePreview();
        }

        ImGui::Spacing();
        ImGui::Text("Batch Export (.txt)");
        ImGui::Separator();
        ImGui::InputInt("samples", &batchSamples);
        if (batchSamples < 1) batchSamples = 1;
        if (batchSamples > 2000) batchSamples = 2000;
        ImGui::InputText("output file", outPath, sizeof(outPath));
        if (ImGui::Button("Export Batch")) {
            string err;
            bool ok = exportBatchTxt(p, batchSamples, outPath, err);
            statusText = ok ? ("Exported to " + string(outPath)) : ("Export failed: " + err);
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextWrapped("Status: %s", statusText.c_str());

        ImGui::End();

        // Preview panel
        ImGui::Begin("Preview");
        ImGui::TextWrapped("ASCII Output Preview (scroll):");
        ImGui::Separator();

        ImGui::BeginChild("preview_scroll", ImVec2(0, 0), true, ImGuiWindowFlags_HorizontalScrollbar);
        ImGui::TextUnformatted(previewText.c_str());
        ImGui::EndChild();

        ImGui::End();

        ImGui::Render();
        SDL_SetRenderDrawColor(renderer, 15, 15, 18, 255);
        SDL_RenderClear(renderer);

        // FIX: too few arguments -> pass renderer
        ImGui_ImplSDLRenderer2_RenderDrawData(ImGui::GetDrawData(), renderer);

        SDL_RenderPresent(renderer);
    }

    ImGui_ImplSDLRenderer2_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
